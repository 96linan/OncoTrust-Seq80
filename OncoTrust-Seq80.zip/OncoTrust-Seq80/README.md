# OncoTrust-Seq80 Data Dictionary

This package is a randomly generated synthetic benchmark shaped to match the dataset and experimental protocol described in the supplied trust-driven agentic offline RL paper.
It contains no real patients, no identifiers, and no clinical facts. It is intended only for code testing, table/figure prototyping, and offline-RL pipeline debugging.

Files:
- patients.csv: one row per synthetic patient.
- treatment_trajectories.csv: one row per treatment cycle, with state, clinician action, reward, risk, and next-state fields.
- splits.csv: patient-level train/validation/test split.
- metadata.json: dataset name, action space, state variables, and experiment protocol.

Recommended use:
- Use patient-level splitting, not row-level random splitting.
- Treat clinician_action_id and dose_level as the behavior-policy action.
- Use reward and next_* fields for offline RL transitions.
- Use high_risk_event, risk_score, and execution_mode for safety/trust analyses.
